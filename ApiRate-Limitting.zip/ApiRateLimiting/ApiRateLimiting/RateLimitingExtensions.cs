﻿using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using System.Net;
using System.Text.Json;
using System.Threading.RateLimiting;

namespace ApiRateLimiting
{
    /// <summary>
    /// Rate limiting options configuration class
    /// </summary>
    public class RateLimitOptions
    {
        public const string SectionName = "RateLimiting";

        // Global rate limiting (requests per window)
        public int GlobalLimit { get; set; } = 100;
        public int GlobalLimitPerWindow { get; set; } = 10;
        public int GlobalWindowSeconds { get; set; } = 60;

        // Per-client rate limiting
        public int ClientLimit { get; set; } = 20;
        public int ClientLimitPerWindow { get; set; } = 5;
        public int ClientWindowSeconds { get; set; } = 30;

        // Throttling settings
        public int MaxConcurrentRequests { get; set; } = 25;

        // Queue settings
        public int QueueLimit { get; set; } = 50;
    }

    /// <summary>
    /// Static extension methods for configuring rate limiting in the application
    /// </summary>
    public static class RateLimitingExtensions
    {
        /// <summary>
        /// Configures rate limiting for the application
        /// </summary>
        public static IServiceCollection AddGemsRateLimiting(this IServiceCollection services, RateLimitOptions options)
        {
            // Register rate limit options
            services.AddSingleton(Options.Create(options));

            // Add core rate limiting services
            services.AddRateLimiter(limiterOptions =>
            {
                // Add a named limiter for global rate limiting
                limiterOptions.AddTokenBucketLimiter("global", globalOptions =>
                {
                    globalOptions.TokenLimit = options.GlobalLimit;
                    globalOptions.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
                    globalOptions.QueueLimit = options.QueueLimit;
                    globalOptions.ReplenishmentPeriod = TimeSpan.FromSeconds(options.GlobalWindowSeconds);
                    globalOptions.TokensPerPeriod = options.GlobalLimitPerWindow;
                    globalOptions.AutoReplenishment = true;
                });

                // Add a named limiter based on client IP
                limiterOptions.AddConcurrencyLimiter("throttle", throttleOptions =>
                {
                    throttleOptions.PermitLimit = options.MaxConcurrentRequests;
                    throttleOptions.QueueLimit = options.QueueLimit;
                    throttleOptions.QueueProcessingOrder = QueueProcessingOrder.OldestFirst;
                });

                // Add a named limiter for per-client rate limiting
                limiterOptions.AddPolicy("clientPolicy", context =>
                {
                    // Get client identifier (IP address, API key, user ID, etc.)
                    string clientId = GetClientIdentifier(context);

                    return RateLimitPartition.GetTokenBucketLimiter(clientId, key => new TokenBucketRateLimiterOptions
                    {
                        TokenLimit = options.ClientLimit,
                        QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                        QueueLimit = options.QueueLimit,
                        ReplenishmentPeriod = TimeSpan.FromSeconds(options.ClientWindowSeconds),
                        TokensPerPeriod = options.ClientLimitPerWindow,
                        AutoReplenishment = true
                    });
                });

                // Global configuration
                limiterOptions.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

                // Override the default rejection handler
                // Override the default rejection handler
                limiterOptions.OnRejected = async (context, token) =>
                {
                    // Determine which policy was used based on endpoint or request path
                    string policyName = DetermineRateLimitPolicy(context.HttpContext);

                    // Create a detailed error response
                    var response = new
                    {
                        Status = (int)HttpStatusCode.TooManyRequests,
                        Title = "Too many requests",
                        Detail = $"You have exceeded the {policyName} rate limit. Please try again later.",
                        RetryAfter = GetRetryAfterHeaderValue(context.Lease)
                    };

                    // Log the rate limit rejection
                    var logger = context.HttpContext.RequestServices.GetRequiredService<ILogger<RateLimitOptions>>();
                    logger.LogWarning("Rate limit exceeded for client {ClientId}. Policy: {Policy}, Path: {Path}",
                        GetClientIdentifier(context.HttpContext),
                        policyName,
                        context.HttpContext.Request.Path);

                    context.HttpContext.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                    context.HttpContext.Response.ContentType = "application/json";

                    // Set retry-after header if available
                    if (context.Lease.TryGetMetadata(MetadataName.RetryAfter, out var retryAfter))
                    {
                        context.HttpContext.Response.Headers["Retry-After"] = retryAfter.ToString();
                    }

                    await context.HttpContext.Response.WriteAsync(JsonSerializer.Serialize(response), token);
                };
            });

            return services;
        }

        /// <summary>
        /// Determines which rate limit policy was applied based on the request
        /// </summary>
        private static string DetermineRateLimitPolicy(HttpContext context)
        {
            // First try to get policy from endpoint metadata
            if (context.GetEndpoint() is Endpoint endpoint)
            {
                // Look for EnableRateLimitingAttribute on the endpoint
                var rateLimitingAttribute = endpoint.Metadata
                    .GetOrderedMetadata<EnableRateLimitingAttribute>()
                    .FirstOrDefault();

                if (rateLimitingAttribute != null)
                {
                    return rateLimitingAttribute.PolicyName ?? "unknown";
                }
            }

            return "unknown";
        }

        /// <summary>
        /// Gets a client identifier from the request
        /// </summary>
        private static string GetClientIdentifier(HttpContext context)
        {
            // Get client IP address
            string? clientIp = context.Connection.RemoteIpAddress?.ToString();

            // API key from header (if available)
            string? apiKey = context.Request.Headers["X-API-Key"].ToString();

            // User ID from claims (if authenticated)
            string? userId = context.User?.Identity?.Name;

            // Use whichever identifier is available, with priority
            return userId ?? apiKey ?? clientIp ?? "unknown";
        }

        /// <summary>
        /// Gets the value for the Retry-After header
        /// </summary>
        private static int GetRetryAfterHeaderValue(RateLimitLease lease)
        {
            if (lease.TryGetMetadata(MetadataName.RetryAfter, out var retryAfter))
            {
                return (int)retryAfter.TotalSeconds;
            }

            return 60; // Default retry time
        }
    }
}
